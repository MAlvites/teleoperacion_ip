#!/usr/bin/python3
import time
import serial

print("UART Demonstration Program")
print("NVIDIA Jetson Nano Developer Kit")


serial_port = serial.Serial(
    port="/dev/ttyTHS0",
    baudrate=115200,
    bytesize=serial.EIGHTBITS,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
)
# Wait a second to let the port initialize
time.sleep(1)
#try:
    # Send a simple header

serial_port.write(b'1')
while True:
	if serial_port.inWaiting() > 0:
		data = serial_port.read()
		print(data)
		serial_port.write(data)
	time.sleep(1)
    # if we get a carriage return, add a line feed too
    # \r is a carriage return; \n is a line feed
    # This is to help the tty program on the other end 
    # Windows is \r\n for carriage return, line feed
    # Macintosh and Linux use \n

#except KeyboardInterrupt:
#    print("Exiting Program")

#except Exception as exception_error:
#    print("Error occurred. Exiting Program")
#    print("Error: " + str(exception_error))

#finally:
#    serial_port.close()
#    pass
